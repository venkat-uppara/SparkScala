package com.sapient.actions

import com.sapient.constants.Constants
import com.sapient.controllers.DataProcessController
import com.sapient.services.{EstablishConnections, Loggers}
import org.apache.logging.log4j.LogManager

object DataProcess extends DataProcessController with EstablishConnections with Serializable with Loggers with Constants{

  def main(args: Array[String]): Unit = {
    @transient lazy val DataProcessLogger = LogManager.getLogger(getClass.getName)
    try{
      DataPipeline()
    } catch{
      case e: Exception => DataProcessLogger.error(DATAPROCESS_ERROR + ":We have an error in the  Data Process " + e.printStackTrace())
        System.exit(1)
    } finally {
      DataProcessLogger.debug(DATAPROCESS_DEBUG + " :End of DATA process")
    }




  }

}
