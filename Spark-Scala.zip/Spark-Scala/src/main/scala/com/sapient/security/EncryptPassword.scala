package com.sapient.security

import com.typesafe.config.ConfigFactory

object EncryptPassword extends Serializable {
  private val key: String = ConfigFactory.load().getString("local.common.SecurityKey.value")
  //private val password: String = ConfigFactory.load().getString("redi.common.CBDataEncryptpassword.value")

  def main(args: Array[String]): Unit = {

    val test= new EncryptSensitiveData

    print(test.encrypt(key,"r3perf"))
  }
}
