package com.sapient.constants

/*
@author : Venkataramana Uppara
@Date : 14/03/2020
@Initial Draft to add constants when connecting to databsae
 */
trait Constants {
  final val CSVFILEPATH ="C:\\SparkCodingTests\\transactions.txt"

  final val COMPETITOR_DATA ="C:\\SparkCodingTests\\test_pack\\data_for_probs\\ecom\\ecom_competitor_data.txt"
  final val INTERNAL_PRODUCT_DATA ="C:\\SparkCodingTests\\test_pack\\data_for_probs\\ecom\\internal_product_data.txt"
  final val SELLER_DATA ="C:\\SparkCodingTests\\test_pack\\data_for_probs\\ecom\\seller_data.txt"

  final val QUESTION_DATA ="C:\\SparkCodingTests\\test_pack\\data_for_probs\\edutech\\question_data.txt"
  final val STUDENT_CONSOLIDATED_REPORT ="C:\\SparkCodingTests\\test_pack\\data_for_probs\\edutech\\student_consolidated_report.txt"
  final val STUDENT_RESPONSE ="C:\\SparkCodingTests\\test_pack\\data_for_probs\\edutech\\student_response.txt"

  final val USERINTERACTIONDATA ="C:\\SparkCodingTests\\test_pack\\data_for_probs\\friendRecommend\\userInteractionData.txt"

  //final val CSVFILEPATH ="r'C:\\SparkCodingTests\\transactions.csv'"
  final val DATAPROCESS_ERROR = "DATAPROCESS_ERROR"
  final val DATAPROCESS_DEBUG = "DATAPROCESS_DEBUG"
  final val DATAPROCESS_INFO = "DATAPROCESS_INFO"
  final val DATAPROCESSAPP = "DataProcess"
  final val APPEND_MODE = "append"
  final val KAFKA_SOURCE = "kafka"
  final val KAFKA_BOOTSTRAP_SERVERS= "kafka.bootstrap.servers"
  final val SUBSCRIBE= "subscribe"
  final val MAXOFFSETSPERTRIGGER= "maxOffsetsPerTrigger"
  final val KAFKA_WRITE_QUERYNAME = "test-with-another-table"
  final val KAFKA_WRITE_FORMAT ="append"
  final val KAFKA_CHECKPOINT_LOCATION="checkpointLocation"
  final val HIVE_SINK = "com.aciworldwide.ra.redi.rstransflow.dao.HiveSinkProvider"
  final val KAFKASECURITYPROTOCOL="kafka.security.protocol"
  final val KAFKASSLKEYSTORELOCATION="kafka.ssl.keystore.location"
  final val KAFKASSLKEYSTOREPASSWORD="kafka.ssl.keystore.password"
  final val KAFKASSLTRUSTSTORELOCATION="kafka.ssl.truststore.location"
  final val KAFKASSLTRUSTSTOREPASSWORD="kafka.ssl.truststore.password"
  final val KAFKASSLKEYPASSWORD="kafka.ssl.key.password"
  final val KAFKASASLKERBEROSSERVICENAME="kafka.sasl.kerberos.service.name"
  final val KAFKASASLMECHANISM="kafka.sasl.mechanism"

  final val SASL_SSL="SASL_SSL"
  final val GSSAPI="GSSAPI"
  final val KAFKA="kafka"

  final val DATABASESERVICES_ERROR  ="DBS_ERROR"
  final val DATABASESERVICES_INFO  ="DBS_INFO"
  final val DATABASESERVICES_DEBUG  ="DBS_DEBUG"
  final val DATA1_DATABASE ="DataBase1"
  final val DATA2_DATABASE ="DataBase1"
  final val DATA3_DATABASE ="DataBase1"

  final val ORACLE_CONN_TYPE ="Oracle"
  final val POSTGRES_CONN_TYPE ="PostGres"

}

