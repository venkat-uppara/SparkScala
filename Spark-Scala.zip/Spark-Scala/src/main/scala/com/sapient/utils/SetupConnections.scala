package com.sapient.utils

import java.sql.Connection

import com.typesafe.config.ConfigFactory
import org.apache.spark.sql.{DataFrame, SparkSession}
import com.sapient.constants.Constants
import scala.collection.mutable.Map
import com.sapient.services.{EstablishConnections, Loggers}
class SetupConnections extends EstablishConnections with Constants{

  val key = ConfigFactory.load().getString("local.common.SecurityKey.value")

  def setupConnectionDetails(sourcedatabase: String, connectionType: String): Map[String,String] ={

    var map = Map[String, String]()

    if(sourcedatabase == DATA1_DATABASE){
      map ("username")= ConfigFactory.load().getString("local.common.ods.db1username")
      map("password") = ConfigFactory.load().getString("local.common.ods.db1password")
    }else if(sourcedatabase == DATA2_DATABASE){
      map ("username")= ConfigFactory.load().getString("local.common.ods.db2username")
      map("password") = ConfigFactory.load().getString("local.common.ods.db2password")
    }else if(sourcedatabase == DATA3_DATABASE) {
      map("username") = ConfigFactory.load().getString("local.common.ods.db3username")
      map("password") = ConfigFactory.load().getString("local.common.ods.db3password")
    }
    if(connectionType == ORACLE_CONN_TYPE) {
      map ("driverclass") = ConfigFactory.load().getString("local.common.ods.driver")
      map("jdbcurl") = ConfigFactory.load().getString("local.common.ods.url")
      map("jdbcurlapsf") = ConfigFactory.load().getString("local.common.ods.urlapsf")
    }else if(connectionType == POSTGRES_CONN_TYPE){
      map("driverclass") = ConfigFactory.load().getString("local.common.postgres.driver")
      map("jdbcurl") = ConfigFactory.load().getString("local.common.postgres.url")
    }
    map
  }

  def readDataIntoDataframe(sc: SparkSession, table: String, connectionType: String, sourcedatabase: String,numPartitions: Int): DataFrame = {

    val map = setupConnectionDetails(sourcedatabase,connectionType)

    val username = map("username")
    val password = map("password")
    val driverclass = map("driverclass")
    var jdbcurl = map("jdbcurl")

  if(username==ConfigFactory.load().getString("local.common.ods.apsfusername"))
    {
      jdbcurl = map("jdbcurlapsf")
    }

    val df = sc.read.format("jdbc")
      .option("url", jdbcurl)
      .option("dbtable", table)
      .option("user", username)
   //   .option("password",decryptPassword(password,key))
      .option("driver",driverclass)
      .option("numPartitions", numPartitions)
      .load()
    df
  }

  def createScalaConnection(sourcedatabase: String, connectionType: String): Connection ={

    val map = setupConnectionDetails(sourcedatabase,connectionType)

    val username = map("username")
    val password = map("password")
    val driverclass = map("driverclass")
    val jdbcurl = map("jdbcurl")
    createScalaJdbcConnection(driverclass,username,//decryptPassword(password,key)
    "" ,jdbcurl)
  }


}
