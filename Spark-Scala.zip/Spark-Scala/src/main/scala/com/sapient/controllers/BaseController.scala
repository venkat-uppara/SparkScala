package com.sapient.controllers

/**
  * Base controller which contains methods that have to be called across all the controllers
  */

import com.typesafe.config.ConfigFactory
import org.apache.spark.sql.SparkSession
import com.sapient.services.{EstablishConnections, Loggers}
class BaseController extends EstablishConnections{
  def createSparkSession(appName: String): SparkSession = {
    val sparkMaster = ConfigFactory.load().getString("local.common.spark.master")
    sparkSessionBuilder(sparkMaster, appName)
  }

}
