package com.sapient.controllers

import java.text.SimpleDateFormat

import com.sapient.constants.Constants
import com.sapient.services.Loggers
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.expressions.Window
import com.typesafe.config.ConfigFactory
import org.apache.spark.SparkContext
import org.apache.spark.SparkConf
import org.apache.spark.sql.{DataFrame, SaveMode}
import org.apache.spark.sql.functions.{current_timestamp, lit, _}
import org.apache.logging.log4j.LogManager
import org.apache.spark.sql.functions.regexp_replace
import shaded.parquet.org.codehaus.jackson.annotate.JsonTypeInfo.As
/*import com.hortonworks.hwc.HiveWarehouseSession
import com.hortonworks.hwc.HiveWarehouseSession.HIVE_WAREHOUSE_CONNECTOR*/

class DataProcessController extends  Serializable with Constants with Loggers{

  @transient lazy val DataTransformationLogger = LogManager.getLogger(getClass.getName)

  val baseController = new BaseController()

  val sparkSession =baseController.createSparkSession(DATAPROCESSAPP)

//  val hivesession= HiveWarehouseSession.session(sparkSession).build()
//  hivesession.setDatabase(REDI_DATABASE)

  import sparkSession.implicits._


   def setFraud = udf((disposition: String) => {
    val despPattern1 = """.*FRAUD.*""".r
    val despPattern2 = """.*fraud.*""".r
    val FraudYN = disposition.take(12) match  {

      case despPattern1()|despPattern2() => "Y"
      case _ => "N"

    }
    FraudYN
  })

  def updateMacysTransId = udf( (transId:String) =>{

    val tmpTransId = "000000000"
    var mTransId:String = null
    if (transId.trim.length < 9){
      mTransId = tmpTransId.take(9 - transId.trim.length)
    }else{
      mTransId = transId
    }
    mTransId
  })


  /** ****************************************************************************************************************************************************
    * This is the method which is invoked by the action
    * ***************************************************************************************************************************************************/

  def DataPipeline(): Unit ={

    DataTransformationLogger.debug(DATAPROCESS_DEBUG +"Start of DataPipeline ")
    /***
    * An Ecom website calculates price of any item dynamically. Dynamic price of any product is computed when user clicks on that product and it is based on prices other competitors are offering at that moment
    * Calculate the price of item subject to following requirements
    * PC => Procuring cost, Q => Cheapest price from other retailer (A product can be sold by multiple competitors)
    *    1.	If PC + MaxMargin  < Q then  PC + MaxMargin
    *    2.	If PC + minMargin  < Q  then Q
    *    3.	If PC < Q,  And competitor with cheapest price is selling it in “Special” sale category then final price is Q.
    *    4.	If Q < PC  && competitor with cheapest price is selling is in “Special” sale category && seller classification  ==  “VeryHigh” then 0.9PC
    *    5.	If none of the conditions is satisfied then PC
    *
    * */
    val competitordataRDD = sparkSession.read.option("header", "true").option("delimiter", "|").csv(COMPETITOR_DATA)
    val internalproducdataRDD = sparkSession.read.option("header", "true").option("delimiter", "|").csv(INTERNAL_PRODUCT_DATA)
    val sellerdataRDD = sparkSession.read.option("header", "true").option("delimiter", "|").csv(SELLER_DATA)

      // Join competitor data and Internal product data based pn Product ID

    val joinRDD =competitordataRDD.join(internalproducdataRDD,Seq("productId"))
      .select($"productId",$"price".cast("double"),$"saleEvent",$"rivalName",$"fetchTS",$"category".alias("productcategory"),$"subcategory",$"procuredValue".cast("double"),$"minMargin".cast("Int")
        ,$"maxMargin".cast("Int"),$"SellerID",$"lastModified")
    // Join competitor data and Internal product data based pn Product ID
     val finalRDD= joinRDD.join(sellerdataRDD,Seq("SellerID")).groupBy($"productId",$"saleEvent",$"rivalName",$"fetchTS",$"productcategory",$"subcategory",$"procuredValue",$"minMargin"
       ,$"maxMargin",$"SellerID",$"lastModified",$"type",$"netValue",$"since",$"userRating").agg(min("price").as("CheapestPrice"))

    // find the  Cheapest price from other retailer

    // Calculate the final price items
    val finalpriceRDD= finalRDD.withColumn("finalprice",
      when(($"procuredValue" + $"maxMargin" lt($"CheapestPrice")),$"procuredValue" + $"maxMargin")
        .when($"procuredValue" + $"minMargin" lt($"CheapestPrice"),$"CheapestPrice" )
        .when($"procuredValue"  lt($"CheapestPrice") and $"saleEvent" === "Special" , $"CheapestPrice" )
         .when($"CheapestPrice"  lt($"procuredValue") and $"saleEvent" === "Special" and $"netValue" === "VeryHigh" ,$"CheapestPrice" * 0.9)
          .otherwise($"procuredValue")
      .cast("double"))

    val df2 = finalpriceRDD.select($"productId",$"finalprice",$"saleEvent",$"lastModified",$"CheapestPrice",regexp_replace($"rivalName","\\.","_").alias("rivalName"))
    df2.write.csv("C:\\SparkCodingTests\\test_pack\\data_for_probs\\ecom_competitor_data")


    // Hive Table
  //  create table competitors(productId string,finalprice double,lastModified timestamp ,CheapestPrice double) PARTITIONED BY (rivalName string)
   /// location ‘/user/hive/ecom_competitor_data.txt’ ;


    /***
     * Pi Simple Education Pvt Ltd (PSE), analyses mock test-series data, finds out weak areas and recommend questions from question bank to help students improve score in next attempt.
     * A Test series constitute multiple question sets. A question set contains multiple questions and these questions are divided into multiple sections (Like English, math, Reasoning)
     * Now this problem has 2 aspects
     * 1.	Finding out weak areas of student in particular exam
     * 2.	Recommend questions of weak areas from question pool
     * */
    val questionsRDD = sparkSession.read.option("header", "true").option("delimiter", "|").csv(QUESTION_DATA)
    val studconsoldreportRDD = sparkSession.read.option("header", "true").option("delimiter", "|").csv(STUDENT_CONSOLIDATED_REPORT)
    val studentresponseRDD = sparkSession.read.option("header", "true").option("delimiter", "|").csv(STUDENT_RESPONSE)

     // 1.	Find students falling in Top 20% (on basis of marks obtained ) in each section

    val joinRDD = studconsoldreportRDD.join(studentresponseRDD,Seq("StudentID","QusetionSet"))
   //val joinRDD=  studconsoldreportRDD.join(studentresponseRDD,studconsoldreportRDD("StudentID") === studentresponseRDD("StudentID") && studconsoldreportRDD("QusetionSet") === studconsoldreportRDD("QusetionSet"),"inner")

   val falling20percenatge =  joinRDD.select($"StudentID",$"QusetionSet",$"QT".cast("Int"),$"QT".cast("Int"),$"QT".cast("Int"),$"QuestionAttempted",$"AttemptDate",
    $"Section",$"QID",$"Answered",$"Result",$"TimeTaken",$"AttemptTS").filter($"Answered" =!= "N" or $"Answered" === " ")

  /* val  studentresponsefilterRdd = joinRDD.filter($"Answered" === "N").select("StudentID","QusetionSet","QT","VB","RA","Section").
     groupBy("StudentID","QusetionSet","QT","VB","RA").sum("QT").alias("QT").show()*/

    // 2.	Find out wrongly answered  and un-attempted questions in that section
   val  wrongandunattemptRDD= studentresponseRDD.filter($"Result" =!= "R")

    //3.	remove “Very difficult” and “Difficult” questions

    val questionsfilterRDD = questionsRDD.filter($"DifficultyLevel" =!= "Difficult" &&  $"DifficultyLevel" =!= "VeryDifficult")

    val RDD1 =  wrongandunattemptRDD.join(questionsfilterRDD,Seq("QID","Section")).groupBy("StudentID","Section","category","DifficultyLevel").count()

    val diffcultDf = RDD1.withColumn("Medium", when( $"DifficultyLevel" === "Medium", "Medium"))
    val diffcultDf1 = diffcultDf.withColumn("Easy", when( $"DifficultyLevel" === "Easy", "Easy"))

    // 5.	Now Fetch 5-“Medium” (MQ) and 5-“Easy” (EQ) questions for each category from question pool

      diffcultDf1.createOrReplaceTempView("Question")

    val  fivemediumandeasyRdd = sparkSession.sql("select * from Question limit 5")

    fivemediumandeasyRdd.write.csv("C:\\SparkCodingTests\\test_pack\\data_for_probs\\scala2");

      //val student = studentresponsefilterRdd.select(col = "StudentID",cols = "Section","QuestionSet","Result").groupBy("Section")
   /* studentresponsefilterRdd.withColumn("percent_rank", percent_rank over studentresponsefilterRdd.select("Result")).show
    studentresponsefilterRdd.select('*', percent_rank().over(Window).alias('rank'))
    .filter(col('rank') <= 0.3) # top 30% for example
      .show() */

    /***
     * Your company is building a software for “friend recommendation” based on email communication of employees.
     * Basic concept:
     *
     * Calvin and Martin are friend of John. Dave is another mutual friend of Calvin and Martin. If John and Dave are not already friend then recommend Dave as friend to John.
     * Data description:
     * 1.	All numbers, except last number, of each row are user Ids
     * 2.	Last number of each row describe time in YYYYMMDD format
     * 3.	First number of each row is primary user who interacted other users on given date
     * 4.	Primary user may interact multiple time with a user in a same day
     * Requirements:
     * Basic Algorithm ->
     * 1.	Find individual connections like A -> B ;  A-> C; B-> A
     * 2.	Calculate weekly strength of connection  i.e. how many times they communicated with each other in last week, something like
     *
     * Person A	Person B	23
     * Person C 	Person D	34
     *
     * 3.	Filter out week connection -> where they communicated less than 3 times a week
     * 4.	After finding friend of a person, find mutual friend of his friends
     * 5.	If mutual friends are found, suggest him for mentioned person.
     *
     * */
    //val userinteradataRDD = sparkSession.read.option("header", "false").csv(USERINTERACTIONDATA)
    val userinteradataRDD = sparkSession.sparkContext.textFile(USERINTERACTIONDATA)

  //  1. Find individual connections like A -> B ;  A-> C; B-> A

    val splitRdd  = userinteradataRDD.map(x => (x.split(" ")(0), x)).groupByKey()

   //  2.	After finding friend of a person, find mutual friend of his friends
     val splitRdd2  = userinteradataRDD.map(x => (x.split(" ")(0), x)).reduceByKey((x, y) => x + y )

    splitRdd2.collect().foreach(println)
  //  RDD.collect().foreach(println)

      DataTransformationLogger.debug(DATAPROCESS_DEBUG +"End of bedDataPipeline ")


  }
}
