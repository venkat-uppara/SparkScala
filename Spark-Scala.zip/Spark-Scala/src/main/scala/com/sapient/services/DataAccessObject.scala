package com.sapient.services

import com.typesafe.config.ConfigFactory
import org.apache.hadoop.security.UserGroupInformation
import org.apache.spark.sql.{DataFrame, SparkSession}

object DataAccessObject extends DataAccess {

  override def readHiveData(spark: SparkSession, table: String): DataFrame = {
    spark
      .read
      .table(table)
  }

  override def writeHiveData(table: String, format: String, dataframe: DataFrame): Unit = {
    dataframe.write.format(format).mode(APPEND_MODE).insertInto(table)
  }

  override def readKafkaData(spark: SparkSession, topic: String): DataFrame = {
    spark.readStream
      .format(KAFKA_SOURCE)
      .option("startingOffsets", "latest")
      .option(KAFKA_BOOTSTRAP_SERVERS, ConfigFactory.load().getString("local.common.kafka.bootstrapservers"))
      .option(SUBSCRIBE, topic)
      .option(MAXOFFSETSPERTRIGGER, ConfigFactory.load().getString("local.common.kafka.tremaxOffsetsPerTrigger"))
      .option(KAFKASECURITYPROTOCOL, SASL_SSL)
      .option(KAFKASSLKEYSTORELOCATION, ConfigFactory.load().getString("local.common.kerberos.Kafkasslkeystorelocation"))
      .option(KAFKASSLKEYSTOREPASSWORD, ConfigFactory.load().getString("local.common.kerberos.kafkasslkeystorepassword"))
      .option(KAFKASSLTRUSTSTORELOCATION, ConfigFactory.load().getString("local.common.kerberos.kafkassltruststorelocation"))
      .option(KAFKASSLTRUSTSTOREPASSWORD, ConfigFactory.load().getString("local.common.kerberos.kafkassltruststorepassword"))
      .option(KAFKASSLKEYPASSWORD, ConfigFactory.load().getString("local.common.kerberos.kafkasslkeypassword"))
      .option(KAFKASASLKERBEROSSERVICENAME, KAFKA)
      .option(KAFKASASLMECHANISM, GSSAPI)
      .load()
  }

  override def createSession(master: String, name: String): SparkSession = {
    UserGroupInformation.loginUserFromKeytab(ConfigFactory.load().getString("local.common.kerberos.userkeyTab"), ConfigFactory.load().getString("local.common.kerberos.servicekeytab"))
    SparkSession
      .builder()
      .master(master)
      .appName(name)
      .config("spark.sql.warehouse.dir", "/apps/hive/warehouse")
      .config("spark.testing.memory", "471859200")
      .config("hive.exec.dynamic.partition", "true")
      .config("hive.exec.dynamic.partition.mode", "nonstrict")
      .config("hive.exec.max.dynamic.partitions", "400")
      .config("hive.exec.max.dynamic.partitions.pernode", "400")
      .config("hive.enforce.bucketing", "true")
      .config("optimize.sort.dynamic.partitionining", "true")
      .config("hive.vectorized.execution.enabled", "true")
      .config("hive.enforce.sorting", "true")
      .config("spark.sql.orc.impl", "native")
      .config("spark.sql.orc.enabled", "true")
      .config("spark.sql.orc.filterPushdown", "true")
      .config("spark.sql.orc.char.enabled", "true")
      .config("spark.sql.cbo.enabled", "true")
      .config("spark.sql.cbo.JoinReorder.enabled", "true")
      .config("spark.sql.hive.metastorePartitionPruning", "true")
      .enableHiveSupport()
      .getOrCreate()

  }

}
